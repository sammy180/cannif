# RP2350_KiCad
Symbols, Footprints &amp; Models for the RP2350
